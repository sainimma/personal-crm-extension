chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url.includes("linkedin.com/in/")) {
    console.log("Not a LinkedIn profile");
    return;
  }

  // Run script in current tab to extract data
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const nameEl = document.querySelector("h1");
      const name = nameEl ? nameEl.innerText.trim() : "";
      const url = window.location.href;
      return { name, url };
    }
  });

  const { name, url } = result.result;
  if (!name || !url) {
    console.log("No data extracted.");
    return;
  }

  const encodedName = encodeURIComponent(name);
  const encodedUrl = encodeURIComponent(url);
  const crmUrl = `https://personal-crm-seven.vercel.app/protected/add-edit-contact?name=${encodedName}&linkedin_url=${encodedUrl}`;

  chrome.tabs.create({ url: crmUrl });
});