chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tabId = tabs[0].id;
  
    chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const nameElem = document.querySelector('h1') || document.querySelector('.text-heading-xlarge');
        const name = nameElem ? nameElem.innerText.trim() : 'Name not found';
        return { name, url: window.location.href };
      },
    }, (results) => {
      const result = results[0].result;
      if (result.url.includes('www.linkedin.com/in')) {
        document.getElementById('url').href = 'https://personal-crm-seven.vercel.app/protected/add-edit-contact?full_name=' + encodeURIComponent(result.name) + '&linkedin_url=' + encodeURIComponent(result.url);
      } else {
        document.getElementById('popup-text').textContent = 'This extension only works when visiting a LinkedIn profile.'
      }
    });
  });